-- MySQL dump 10.13  Distrib 9.6.0, for macos15.7 (arm64)
--
-- Host: localhost    Database: mvc_db
-- ------------------------------------------------------
-- Server version	9.6.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '3951cfea-4ac8-11f1-939b-bbfcc1cec573:1-935';

--
-- Table structure for table `authorBook`
--

DROP TABLE IF EXISTS `authorBook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authorBook` (
  `a_id` int NOT NULL,
  `b_id` int NOT NULL,
  PRIMARY KEY (`a_id`,`b_id`),
  KEY `b_id` (`b_id`),
  CONSTRAINT `authorbook_ibfk_1` FOREIGN KEY (`a_id`) REFERENCES `authors` (`a_id`) ON DELETE CASCADE,
  CONSTRAINT `authorbook_ibfk_2` FOREIGN KEY (`b_id`) REFERENCES `books` (`b_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authorBook`
--

LOCK TABLES `authorBook` WRITE;
/*!40000 ALTER TABLE `authorBook` DISABLE KEYS */;
INSERT INTO `authorBook` VALUES (1,1),(2,2),(3,3),(4,4),(5,5),(6,6),(7,7),(8,8),(9,9),(10,10),(11,11),(12,12),(13,13),(14,14),(15,15),(16,16),(17,17),(18,18),(19,19),(20,20),(21,21),(22,22),(23,23),(24,24),(4,29);
/*!40000 ALTER TABLE `authorBook` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `authors`
--

DROP TABLE IF EXISTS `authors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authors` (
  `a_id` int NOT NULL AUTO_INCREMENT,
  `a_name` varchar(100) NOT NULL,
  PRIMARY KEY (`a_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authors`
--

LOCK TABLES `authors` WRITE;
/*!40000 ALTER TABLE `authors` DISABLE KEYS */;
INSERT INTO `authors` VALUES (1,'Андрей Богуславский'),(2,'Марк Саммерфильд'),(3,'М., Вильямс'),(4,'Уэс Маккинни'),(5,'Брюс Эккель'),(6,'Томас Кормен, Чарльз Лейзерсон, Рональд Ривест, Клиффорд Штайн'),(7,'Дэвид Флэнаган'),(8,'Гэри Маклин Холл'),(9,'Джеймс Р. Грофф'),(10,'Люк Веллинг'),(11,'Сергей Мастицкий'),(12,'Джон Вудкок'),(13,'Джереми Блум'),(14,'А. Белов'),(15,'Сэмюэл Грингард'),(16,'Сет Гринберг'),(17,'Александр Сераков'),(18,'Тим Кедлек'),(19,'Пол Дейтел, Харви Дейтел'),(20,'Роберт Мартин'),(21,'Энтони Грей'),(22,'Мартин Фаулер, Прамодкумар Дж. Садаладж'),(23,'Джей Макгаврен'),(24,'Дрю Нейл'),(26,'Герман Гессе');
/*!40000 ALTER TABLE `authors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `books`
--

DROP TABLE IF EXISTS `books`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `books` (
  `b_id` int NOT NULL AUTO_INCREMENT,
  `b_name` varchar(100) NOT NULL,
  `b_desc` varchar(300) NOT NULL,
  `b_img` varchar(100) NOT NULL,
  `b_year` varchar(10) NOT NULL,
  PRIMARY KEY (`b_id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `books`
--

LOCK TABLES `books` WRITE;
/*!40000 ALTER TABLE `books` DISABLE KEYS */;
INSERT INTO `books` VALUES (1,'СИ++ И КОМПЬЮТЕРНАЯ ГРАФИКА','Книга про СИ++ И КОМПЬЮТЕРНАЯ ГРАФИКА','22.jpg','2024-01-01'),(2,'Программирование на языке Go!','Книга про Программирование на языке Go!','23.jpg','2024-01-01'),(3,'Толковый словарь сетевых терминов и аббревиатур','Книга про Толковый словарь сетевых терминов и аббревиатур','25.jpg','2024-01-01'),(4,'Python for Data Analysis','Книга про Python for Data Analysis','26.jpg','2013'),(5,'Thinking in Java (4th Edition)','Книга про Thinking in Java (4th Edition)','27.jpg','2024-01-01'),(6,'Introduction to Algorithms','Книга про Introduction to Algorithms','29.jpg','2024-01-01'),(7,'JavaScript Pocket Reference','Книга про JavaScript Pocket Reference','31.jpg','2024-01-01'),(8,'Adaptive Code via C#: Class and Interface Design, Design Patterns, and SOLID Principles','Книга про Adaptive Code via C#','32.jpg','2024-01-01'),(9,'SQL: The Complete Reference','Книга про SQL: The Complete Reference','33.jpg','2024-01-01'),(10,'PHP and MySQL Web Development','Книга про PHP and MySQL Web Development','34.jpg','2011'),(11,'Статистический анализ и визуализация данных с помощью R','Книга про Статистический анализ и визуализация данных с помощью R','35.jpg','2024-01-01'),(12,'Computer Coding for Kids','Книга про Computer Coding for Kids','36.jpg','2024-01-01'),(13,'Exploring Arduino: Tools and Techniques for Engineering Wizardry','Книга про Exploring Arduino','37.jpg','2024-01-01'),(14,'Программирование микроконтроллеров для начинающих и не только','Книга про Программирование микроконтроллеров','38.jpg','2024-01-01'),(15,'The Internet of Things','Книга про The Internet of Things','39.jpg','2024-01-01'),(16,'Sketching User Experiences: The Workbook','Книга про Sketching User Experiences','40.jpg','2024-01-01'),(17,'InDesign CS6','Книга про InDesign CS6','41.jpg','2024-01-01'),(18,'Адаптивный дизайн. Делаем сайты для любых устройств','Книга про Адаптивный дизайн','42.jpg','2024-01-01'),(19,'Android для разработчиков','Книга про Android для разработчиков','43.jpg','2024-01-01'),(20,'Clean Code: A Handbook of Agile Software Craftsmanship','Книга про Clean Code','44.jpg','2024-01-01'),(21,'Swift Pocket Reference: Programming for iOS and OS X','Книга про Swift Pocket Reference','45.jpg','2024-01-01'),(22,'NoSQL Distilled: A Brief Guide to the Emerging World of Polyglot Persistence','Книга про NoSQL Distilled','46.jpg','2024-01-01'),(23,'Head First Ruby','Книга про Head First Ruby','47.jpg','2024-01-01'),(24,'Practical Vim','Книга про Practical Vim','48.jpg','2024-01-01'),(29,'bla',' bla bla','icon.jpg','2005');
/*!40000 ALTER TABLE `books` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bookViews`
--

DROP TABLE IF EXISTS `bookViews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bookViews` (
  `b_id` int NOT NULL,
  `b_count` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`b_id`),
  CONSTRAINT `bookviews_ibfk_1` FOREIGN KEY (`b_id`) REFERENCES `books` (`b_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bookViews`
--

LOCK TABLES `bookViews` WRITE;
/*!40000 ALTER TABLE `bookViews` DISABLE KEYS */;
INSERT INTO `bookViews` VALUES (1,2),(2,1),(3,0),(4,0),(5,0),(6,0),(7,0),(8,0),(9,0),(10,0),(11,0),(12,0),(13,0),(14,0),(15,0),(16,0),(17,0),(18,0),(19,0),(20,0),(21,0),(22,0),(23,0),(24,0),(29,0);
/*!40000 ALTER TABLE `bookViews` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-20 17:34:02
